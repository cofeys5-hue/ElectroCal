ElectroCalc Android project
===========================

Features:
- Calculate W, V or A from the other two values
- Power factor cos(phi) field for single-phase AC calculations
- Calculation history saved locally on the device
- Greek interface

Important:
- This ZIP contains Android source project files, not a ready-to-install APK.
- It must be built with Android Gradle Plugin 8.7.3 / Gradle 8.9 and JDK 17.
- The app currently covers the single-phase/DC formulas; three-phase mode is not yet implemented.
- For AC active power: P = V × I × cos(phi). Voltage/Current reverse calculations assume the same model and known power factor.
