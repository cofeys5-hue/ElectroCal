package com.electrocalc.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private var mode = 0 // 0=W, 1=V, 2=A
    private lateinit var first: EditText
    private lateinit var second: EditText
    private lateinit var pf: EditText
    private lateinit var result: TextView
    private lateinit var history: LinearLayout
    private val prefs by lazy { getSharedPreferences("electrocalc", Context.MODE_PRIVATE) }
    private val modes = arrayOf("Υπολογισμός Watt (W)", "Υπολογισμός Volt (V)", "Υπολογισμός Ampere (A)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        renderHistory()
        calculate()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(Color.rgb(71,85,105))
        setPadding(0, dp(10), 0, dp(4))
    }
    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 17f
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        setSingleLine(true); setPadding(dp(12), dp(8), dp(12), dp(8))
        setBackgroundColor(Color.rgb(248,250,252))
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(241,245,249))
            setPadding(dp(18), dp(18), dp(18), dp(12))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = TextView(this).apply {
            text = "⚡ ElectroCalc"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); setPadding(dp(16), dp(18), dp(16), dp(18))
            setBackgroundColor(Color.rgb(15,23,42))
        }
        content.addView(header)
        content.addView(label("Τι θέλεις να υπολογίσεις;"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        spinner.setSelection(mode)
        content.addView(spinner)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                mode = position
                first.hint = if (mode == 0) "Τάση σε Volt" else "Ισχύς σε Watt"
                second.hint = if (mode == 2) "Τάση σε Volt" else "Ρεύμα σε Ampere"
                calculate()
            }
        }
        content.addView(label("Πρώτη τιμή"))
        first = field("Τάση σε Volt", "230")
        content.addView(first)
        content.addView(label("Δεύτερη τιμή"))
        second = field("Ρεύμα σε Ampere", "0.4")
        content.addView(second)
        content.addView(label("Συντελεστής ισχύος cos φ (βάλε 1 για DC/ωμικό φορτίο)"))
        pf = field("0 έως 1", "1")
        content.addView(pf)
        val calc = button("ΥΠΟΛΟΓΙΣΜΟΣ") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(first.windowToken, 0)
            calculate()
        }
        content.addView(calc)
        result = TextView(this).apply {
            textSize = 25f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(37,99,235))
            gravity = Gravity.CENTER; setPadding(dp(8), dp(20), dp(8), dp(20))
            setBackgroundColor(Color.WHITE)
        }
        content.addView(result)
        content.addView(label("Ιστορικό υπολογισμών"))
        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(history)
        content.addView(button("Καθαρισμός ιστορικού") {
            prefs.edit().remove("history").apply(); renderHistory()
        })
        val note = TextView(this).apply {
            text = "Προσοχή: Για AC, τα Watt υπολογίζονται ως V × A × cos φ. Για τριφασικό σύστημα απαιτείται διαφορετικός τύπος."
            textSize = 12f; setTextColor(Color.DKGRAY); setPadding(0, dp(12), 0, dp(12))
        }
        content.addView(note)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { calculate() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        first.addTextChangedListener(watcher); second.addTextChangedListener(watcher); pf.addTextChangedListener(watcher)
    }

    private fun number(e: EditText): Double? = e.text.toString().trim().replace(',', '.').toDoubleOrNull()
    private fun calculate() {
        if (!::result.isInitialized || !::first.isInitialized || !::second.isInitialized || !::pf.isInitialized) return
        val x = number(first); val y = number(second); val factor = number(pf)
        if (x == null || y == null || factor == null || x < 0 || y < 0 || factor <= 0 || factor > 1) {
            result.text = "Έλεγξε τις τιμές"; return
        }
        val answer: Double
        val unit: String
        val expression: String
        when (mode) {
            0 -> { answer = x * y * factor; unit = "W"; expression = "$x V × $y A × cosφ $factor" }
            1 -> { if (y == 0.0 || factor == 0.0) { result.text = "Το ρεύμα πρέπει να είναι > 0"; return }
                answer = x / (y * factor); unit = "V"; expression = "$x W ÷ ($y A × cosφ $factor)" }
            else -> { if (y == 0.0 || factor == 0.0) { result.text = "Η τάση πρέπει να είναι > 0"; return }
                answer = x / (y * factor); unit = "A"; expression = "$x W ÷ ($y V × cosφ $factor)" }
        }
        if (!answer.isFinite()) { result.text = "Μη έγκυρο αποτέλεσμα"; return }
        val pretty = String.format(java.util.Locale("el", "GR"), "%.4f", answer).trimEnd('0').trimEnd(',')
        result.text = "Αποτέλεσμα\n$pretty $unit"
        saveHistory("$expression = $pretty $unit")
    }

    private fun saveHistory(line: String) {
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        if (arr.length() > 0 && arr.optString(0) == line) return
        arr.put(0, line)
        while (arr.length() > 15) arr.remove(arr.length() - 1)
        prefs.edit().putString("history", arr.toString()).apply()
        renderHistory()
    }

    private fun renderHistory() {
        if (!::history.isInitialized) return
        history.removeAllViews()
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) {
            history.addView(TextView(this).apply { text = "Δεν υπάρχουν ακόμη υπολογισμοί."; setPadding(0, dp(6), 0, dp(6)) })
        } else for (i in 0 until arr.length()) {
            history.addView(TextView(this).apply {
                text = "• " + arr.optString(i); textSize = 13f; setTextColor(Color.rgb(30,41,59))
                setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(Color.WHITE)
            })
        }
    }
}
